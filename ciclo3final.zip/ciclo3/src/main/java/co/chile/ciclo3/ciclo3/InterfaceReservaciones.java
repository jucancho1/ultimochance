
package co.chile.ciclo3.ciclo3;

import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author juanp
 */
public interface InterfaceReservaciones extends CrudRepository<Reservaciones, Integer> {

}
