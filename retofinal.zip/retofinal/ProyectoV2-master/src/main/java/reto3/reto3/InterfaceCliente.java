
package reto3.reto3;

import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author JuanK
 */
public interface InterfaceCliente extends CrudRepository<Cliente, Integer>{
    
}
