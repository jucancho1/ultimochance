
package reto3.reto3;

import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author JuanK
 */
public interface InterfaceReservaciones extends CrudRepository<Reservaciones, Integer>{
    
}
